Behavioral Tests

Behavioral test1 Tests if the user can retrieve a form from cognito.com, and have alexa read a question from the form.

Intructions: From the root of the project folder, type the following into the command prompt:

npm run behave1
